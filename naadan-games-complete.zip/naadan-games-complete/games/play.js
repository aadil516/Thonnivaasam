
const params = new URLSearchParams(window.location.search);
const gameName = params.get("game");

const gameArea = document.getElementById("gameArea");
const gameBoard = document.getElementById("gameBoard");
const gameTitle = document.getElementById("gameTitle");
const scoreElement = document.getElementById("score");
const scoreLabel = document.getElementById("scoreLabel");
const timerElement = document.getElementById("timer");
const timerLabel = document.getElementById("timerLabel");
const startScreen = document.getElementById("startScreen");
const startIcon = document.getElementById("startIcon");
const startTitle = document.getElementById("startTitle");
const instructions = document.getElementById("gameInstructions");
const startBtn = document.getElementById("startBtn");
const restartBtn = document.getElementById("restartBtn");
const gameHelp = document.getElementById("gameHelp");

let score = 0;
let timer = 30;
let running = false;
let interval = null;
let animationFrame = null;
let cleanup = null;
let generation = 0;

const configs = {
    neon: {
        title: "Neon Drift",
        icon: "🏎️",
        instructions: "Dodge the incoming cars using ← → or A/D. Tap the left or right side on mobile.",
        help: "Avoid the red cars and survive as long as possible."
    },
    memory: {
        title: "Tiny Tactics",
        icon: "🧩",
        instructions: "Flip two cards at a time and find all nine matching pairs.",
        help: "Try to match every pair in as few moves as possible."
    },
    bubble: {
        title: "Bubble Trouble",
        icon: "🫧",
        instructions: "Click or tap the bouncing bubbles to pop them before time runs out.",
        help: "Pop as many bubbles as possible in 30 seconds."
    }
};

function updateScore(value) {
    score = value;
    scoreElement.textContent = score;
}

function updateTimer(value) {
    timer = value;
    timerElement.textContent = value;
}

function stopRuntime() {
    running = false;
    generation++;

    if (interval) clearInterval(interval);
    if (animationFrame) cancelAnimationFrame(animationFrame);
    if (cleanup) cleanup();

    interval = null;
    animationFrame = null;
    cleanup = null;

    document.onkeydown = null;
    gameBoard.innerHTML = "";
    gameBoard.className = "game-board";
}

function showStartScreen() {
    stopRuntime();

    updateScore(0);
    updateTimer(30);

    timerLabel.hidden = false;
    scoreLabel.innerHTML = 'Score: <strong id="score">0</strong>';

    startScreen.hidden = false;
    startBtn.hidden = false;
    startBtn.textContent = "Start Game";

    if (!configs[gameName]) {
        gameTitle.textContent = "Game Not Found";
        startIcon.textContent = "🤔";
        startTitle.textContent = "Unknown game";
        instructions.textContent = "Return to the homepage and select a game.";
        startBtn.hidden = true;
        return;
    }

    const config = configs[gameName];

    gameTitle.textContent = config.title;
    startIcon.textContent = config.icon;
    startTitle.textContent = "Ready to play?";
    instructions.textContent = config.instructions;
    gameHelp.textContent = config.help;
}

function finishGame(message, showCrashPhoto = false) {
    if (!running) return;

    stopRuntime();

    const storageKey = `naadan-best-${gameName}`;
    const oldBest = Number(localStorage.getItem(storageKey) || 0);
    const newBest = Math.max(oldBest, score);

    localStorage.setItem(storageKey, String(newBest));

    startScreen.hidden = false;
    if (showCrashPhoto && gameName === "neon") {
        startIcon.innerHTML = '<img class="crash-photo-icon" src="images/crash-image.jpg" alt="Crash screen" />';
    } else {
        startIcon.textContent = "🏆";
    }
    startTitle.textContent = message;
    instructions.textContent = `Score: ${score} · Best score: ${newBest}`;
    startBtn.textContent = "Play Again";
}

function startClock(seconds = 30) {
    updateTimer(seconds);

    interval = setInterval(() => {
        if (!running) return;

        updateTimer(timer - 1);

        if (timer <= 0) {
            finishGame("Time's up!");
        }
    }, 1000);
}

function startGame() {
    stopRuntime();

    updateScore(0);
    updateTimer(30);

    running = true;
    startScreen.hidden = true;

    if (gameName === "neon") startNeon();
    if (gameName === "memory") startMemory();
    if (gameName === "bubble") startBubble();
}

/* ---------------- NEON DRIFT ---------------- */

function startNeon() {
    gameBoard.classList.add("neon");

    const road = document.createElement("div");
    road.className = "road";
    gameBoard.appendChild(road);

    const player = document.createElement("div");
    player.className = "car player-car";

    const playerImage = document.createElement("img");
    playerImage.src = "images/player-car.jpg";
    playerImage.alt = "Player character";
    playerImage.draggable = false;
    player.appendChild(playerImage);
    road.appendChild(player);

    const lanePositions = [15, 43, 71];
    let lane = 1;
    let frame = 0;
    let speed = 3;
    let enemies = [];
    let lines = [];

    for (let i = 0; i < 5; i++) {
        const line = document.createElement("div");
        line.className = "road-line";
        road.appendChild(line);
        lines.push({ element: line, y: i * 110 });
    }

    function positionPlayer() {
        player.style.left = `${lanePositions[lane]}%`;
    }

    positionPlayer();

    function movePlayer(direction) {
        if (!running) return;
        lane = Math.max(0, Math.min(2, lane + direction));
        positionPlayer();
    }

    document.onkeydown = (event) => {
        if (["ArrowLeft", "ArrowRight", "a", "d", "A", "D"].includes(event.key)) {
            event.preventDefault();
        }

        if (event.key === "ArrowLeft" || event.key.toLowerCase() === "a") {
            movePlayer(-1);
        }

        if (event.key === "ArrowRight" || event.key.toLowerCase() === "d") {
            movePlayer(1);
        }
    };

    const pointerHandler = (event) => {
        const rect = road.getBoundingClientRect();
        movePlayer(event.clientX - rect.left < rect.width / 2 ? -1 : 1);
    };

    road.addEventListener("pointerdown", pointerHandler);

    function spawnEnemy() {
        const enemy = document.createElement("div");
        enemy.className = "car enemy-car";
        enemy.textContent = "🚗";

        const enemyLane = Math.floor(Math.random() * 3);
        enemy.style.left = `${lanePositions[enemyLane]}%`;
        enemy.style.top = "-75px";
        road.appendChild(enemy);

        enemies.push({ element: enemy, lane: enemyLane, y: -75 });
    }

    function loop() {
        if (!running) return;

        frame++;

        lines.forEach((line) => {
            line.y += speed;

            if (line.y > road.clientHeight) line.y = -60;

            line.element.style.top = `${line.y}px`;
        });

        if (frame % 48 === 0) spawnEnemy();
        if (frame % 500 === 0) speed += 0.5;

        const playerY = road.clientHeight - 90;

        for (const enemy of enemies) {
            enemy.y += speed;
            enemy.element.style.top = `${enemy.y}px`;

            const collision =
                enemy.lane === lane &&
                enemy.y + 55 >= playerY &&
                enemy.y <= playerY + 60;

            if (collision) {
                finishGame("Crash!", true);
                return;
            }
        }

        const remaining = [];

        enemies.forEach((enemy) => {
            if (enemy.y > road.clientHeight) {
                enemy.element.remove();
                updateScore(score + 1);
            } else {
                remaining.push(enemy);
            }
        });

        enemies = remaining;
        animationFrame = requestAnimationFrame(loop);
    }

    cleanup = () => road.removeEventListener("pointerdown", pointerHandler);

    startClock(30);
    loop();
}

/* ---------------- TINY TACTICS ---------------- */

function startMemory() {
    timerLabel.hidden = true;
    scoreLabel.innerHTML = 'Moves: <strong id="score">0</strong>';

    const imageFiles = [
        "tile-01.jpg", "tile-02.jpg", "tile-03.jpg",
        "tile-04.jpg", "tile-05.jpg", "tile-06.jpg",
        "tile-07.jpg", "tile-08.jpg", "tile-09.jpg"
    ];
    const cards = imageFiles.flatMap((file, pairId) => [
        { file, pairId }, { file, pairId }
    ]);

    for (let i = cards.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [cards[i], cards[j]] = [cards[j], cards[i]];
    }

    const grid = document.createElement("div");
    grid.className = "memory-grid";
    gameBoard.appendChild(grid);

    let first = null;
    let locked = false;
    let matches = 0;
    let moves = 0;
    let mismatchTimeout = null;

    cards.forEach((cardData) => {
        const button = document.createElement("button");
        button.className = "memory-card";
        button.textContent = "?";
        button.dataset.pairId = String(cardData.pairId);
        button.setAttribute("aria-label", "Hidden card");

        button.addEventListener("click", () => {
            if (
                !running ||
                locked ||
                button === first ||
                button.classList.contains("matched") ||
                button.classList.contains("revealed")
            ) return;

            const image = document.createElement("img");
            image.src = `images/${cardData.file}`;
            image.alt = "Revealed matching card";
            image.draggable = false;
            button.replaceChildren(image);
            button.classList.add("revealed");
            button.setAttribute("aria-label", "Revealed card");

            if (!first) {
                first = button;
                return;
            }

            moves++;
            updateScore(moves);
            locked = true;

            if (first.dataset.pairId === button.dataset.pairId) {
                first.classList.add("matched");
                button.classList.add("matched");

                first = null;
                locked = false;
                matches++;

                if (matches === imageFiles.length) {
                    finishGame("All pairs matched!");
                }
            } else {
                const previous = first;
                first = null;
                const currentGeneration = generation;

                mismatchTimeout = setTimeout(() => {
                    if (!running || currentGeneration !== generation) return;

                    previous.textContent = "?";
                    button.textContent = "?";
                    previous.classList.remove("revealed");
                    button.classList.remove("revealed");
                    previous.setAttribute("aria-label", "Hidden card");
                    button.setAttribute("aria-label", "Hidden card");
                    locked = false;
                }, 700);
            }
        });

        grid.appendChild(button);
    });

    cleanup = () => {
        if (mismatchTimeout) clearTimeout(mismatchTimeout);
    };
}

/* ---------------- BUBBLE TROUBLE ---------------- */

function startBubble() {
    gameBoard.classList.add("bubble-game");

    let bubbles = [];
    let lastSpawn = 0;

    function spawnBubble() {
        const size = 35 + Math.random() * 35;
        const bubble = document.createElement("button");

        bubble.className = "bubble";
        bubble.style.width = `${size}px`;
        bubble.style.height = `${size}px`;
        bubble.setAttribute("aria-label", "Pop bubble");

        const bubbleImage = document.createElement("img");
        bubbleImage.src = "images/bubble-image.jpg";
        bubbleImage.alt = "";
        bubbleImage.draggable = false;
        bubble.appendChild(bubbleImage);

        const maxX = Math.max(0, gameBoard.clientWidth - size);
        const maxY = Math.max(0, gameBoard.clientHeight - size);

        const item = {
            element: bubble,
            x: Math.random() * maxX,
            y: Math.random() * maxY,
            vx: (Math.random() - 0.5) * 4,
            vy: (Math.random() - 0.5) * 4,
            size,
            popped: false
        };

        bubble.addEventListener("click", () => {
            if (!running || item.popped) return;

            item.popped = true;
            bubble.remove();
            updateScore(score + 1);
        });

        gameBoard.appendChild(bubble);
        bubbles.push(item);
    }

    function loop(timestamp) {
        if (!running) return;

        const active = bubbles.filter((bubble) => !bubble.popped);

        if (timestamp - lastSpawn > 650 && active.length < 12) {
            spawnBubble();
            lastSpawn = timestamp;
        }

        bubbles.forEach((bubble) => {
            if (bubble.popped) return;

            bubble.x += bubble.vx;
            bubble.y += bubble.vy;

            const maxX = Math.max(0, gameBoard.clientWidth - bubble.size);
            const maxY = Math.max(0, gameBoard.clientHeight - bubble.size);

            if (bubble.x <= 0 || bubble.x >= maxX) bubble.vx *= -1;
            if (bubble.y <= 0 || bubble.y >= maxY) bubble.vy *= -1;

            bubble.x = Math.max(0, Math.min(maxX, bubble.x));
            bubble.y = Math.max(0, Math.min(maxY, bubble.y));

            bubble.element.style.left = `${bubble.x}px`;
            bubble.element.style.top = `${bubble.y}px`;
        });

        bubbles = bubbles.filter((bubble) => !bubble.popped);

        animationFrame = requestAnimationFrame(loop);
    }

    startClock(30);
    animationFrame = requestAnimationFrame(loop);
}

startBtn.addEventListener("click", startGame);
restartBtn.addEventListener("click", showStartScreen);

showStartScreen();
